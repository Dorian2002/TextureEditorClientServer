#pragma once

#include "PerlinOperators.h"

class PerlinOperatorData : PerlinOperator
{
public:
	int octave;
	float frequence;
};

